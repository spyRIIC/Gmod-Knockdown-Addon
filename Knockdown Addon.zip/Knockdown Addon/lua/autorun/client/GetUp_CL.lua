local function GetUp(ply, pos, angles, fov)
if ply.GettingUp == true then
if ply.GetUp_P_Go then
if ply.GetUp_P_GoDIR == true then
ply.GetUp_P = ply.GetUp_P + RealFrameTime()*110
if ply.GetUp_P >= 40 then ply.GetUp_P = 40;ply.GetUp_P_GoDIR = false end
end
if ply.GetUp_P_GoDIR == false then
ply.GetUp_P = ply.GetUp_P - RealFrameTime()*100
if ply.GetUp_P <= 0 then ply.GetUp_P = 0;ply.GetUp_P_Go = false;ply.GetUp_P_GoDIR = true end
end
end
if ply.GetUp_R_Go then
if ply.GetUp_R_GoDIR == true then
ply.GetUp_R = ply.GetUp_R + RealFrameTime()*54
if ply.GetUp_R > 40 then ply.GetUp_R = 40;ply.GetUp_R_GoDIR = false end
end
if ply.GetUp_R_GoDIR == false then
ply.GetUp_R = ply.GetUp_R - RealFrameTime()*52
if ply.GetUp_R < 0 then ply.GetUp_R = 0;ply.GetUp_R_Go = false;ply.GetUp_R_GoDIR = true end
end
end
if ply.GetUp_R <= 0 and ply.GetUp_P >= 0 and ply.GetUp_R_Go == false and ply.GetUp_P_Go == false then ply.GettingUp = false end
angles.p = ply.GetUp_P
angles.r = ply.GetUp_R
--angles.y = ply.GetUp_Y
end
if ply.KnockedDown == true then
ply.KDown_P = ply.KDown_P - RealFrameTime()*220
if ply.KDown_P <= -75 then ply.KDown_P = -75 end
angles.p = ply.KDown_P
end
end
hook.Add("CalcView","GetUp",GetUp)

local function KnockedDownMS( um )
LocalPlayer().KDown_P = 0
LocalPlayer().KnockedDown = true
end
usermessage.Hook( "KnockedDownMS", KnockedDownMS )

local function GetUpMS( um )
LocalPlayer().GetUp_P = -75
LocalPlayer().GetUp_R = 0
LocalPlayer().GetUp_P_Go = true
LocalPlayer().GetUp_P_GoDIR = true
LocalPlayer().GetUp_R_GoDIR = true
LocalPlayer().GetUp_R_Go = true
LocalPlayer().KnockedDown = false
LocalPlayer().GettingUp = true
LocalPlayer().TogQ = false
end
usermessage.Hook( "GetUpMS", GetUpMS )

local function GetUpForceVar( um )
LocalPlayer().KnockedDown = false
LocalPlayer().GettingUp = false
end
usermessage.Hook( "SpawnedGUPMS", GetUpForceVar )

function NoAttackGU( ply, bind, pressed )
/*
if not pressed then return false end
if (bind == "+attack" and (ply.KnockedDown == true or ply.GettingUp == true)) then return true end
if (bind == "+attack2" and (ply.KnockedDown == true or ply.GettingUp == true)) then return true end
*/
end
hook.Add( "PlayerBindPress", "NoAttackGU", NoAttackGU )

function GetUpResetPitch(UCMD)
/*
if LocalPlayer().GettingUp == true then
local ang=UCMD:GetViewAngles()
ang.p = 0
UCMD:SetViewAngles(ang)
end
*/
end
hook.Add("CreateMove", "GetUpCalcViewSet", GetUpResetPitch)