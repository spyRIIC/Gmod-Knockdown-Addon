local FUCKOFFWEAPONS = {
"weapon_physgun",
"weapon_physcannon",
"weapon_pistol",
"weapon_crowbar",
"weapon_slam",
"weapon_357",
"weapon_smg1",
"weapon_ar2",
"weapon_crossbow",
"weapon_shotgun",
"weapon_frag",
"weapon_stunstick",
"weapon_rpg",
"gmod_camera",
"gmod_toolgun"}

function GETUP_Spawn(ply)
ply.KnockedDown = false
ply.KnockImmunity = CurTime() + 2
ply.GetUp = false
ply:GetViewModel():SetNoDraw(false)
ply:ConCommand("-duck")
umsg.Start("SpawnedGUPMS",ply)
umsg.End()
end
hook.Add("PlayerSpawn","GETUP_Spawn",GETUP_Spawn)

function GETUP_Death(ply)
ply.KnockedDown = false
ply.GetUp = false
umsg.Start("SpawnedGUPMS",ply)
umsg.End()
end
hook.Add("DoPlayerDeath","GETUP_Death",GETUP_Death)

function GETUP_Ground(ply)
if ply.KnockedDown == true then
ply.KnockedDown = false
ply.GetUpReal = CurTime() + 1.3
umsg.Start("GetUpMS",ply)
umsg.End()
end
end
hook.Add("OnPlayerHitGround","GETUP_Ground",GETUP_Ground)

local FUCKOFFWEAPONS = {
"weapon_physgun",
"weapon_physcannon",
"weapon_pistol",
"weapon_crowbar",
"weapon_slam",
"weapon_357",
"weapon_smg1",
"weapon_ar2",
"weapon_crossbow",
"weapon_shotgun",
"weapon_frag",
"weapon_stunstick",
"weapon_rpg",
"gmod_camera",
"gmod_toolgun"}

KnockDownInstalled = true

function GETUP_Think()
for k,v in pairs (player.GetAll()) do
if v:WaterLevel() >= 1 and v.KnockedDown == true then
v.GUReset = nil
v.KnockedDown = false
v.GetUpReal = CurTime() + 1
umsg.Start("GetUpMS",v)
umsg.End()
end
if v.GetUpReal and CurTime() >= v.GetUpReal then
v:ConCommand("-duck")
if v:GetActiveWeapon():IsValid() then
if table.HasValue(FUCKOFFWEAPONS,v:GetActiveWeapon():GetClass()) then
v:GetActiveWeapon():SendWeaponAnim(ACT_VM_DRAW)
else
v:GetActiveWeapon():Deploy()
end
end
v:GetViewModel():SetNoDraw(false)
v.GetUpReal = nil
v.GetUp = true
end
if v.KnockedDown == true and v.GUReset and CurTime() >= v.GUReset and v:OnGround() then
if v:OnGround() or v:WaterLevel() >= 1 then
v.GUReset = nil
v.KnockedDown = false
v:SetFOV(0,0.3)
v.GetUpReal = CurTime() + 1
umsg.Start("GetUpMS",v)
umsg.End()
end
end
end
end
hook.Add("Think","GETUP_Think",GETUP_Think)

local ShieldDamageSuccess = {
"weapons/fx/rics/ric1.wav",
"weapons/fx/rics/ric2.wav",
"weapons/fx/rics/ric3.wav",
"weapons/fx/rics/ric4.wav",
"weapons/fx/rics/ric5.wav"}

function GETUPTakeDamage(ent, inflictor, attacker, amount, dmginfo)
if ent:IsPlayer() and (attacker:GetClass() == "npc_antlionguard" or (amount >= 50 and (dmginfo:IsFallDamage() or dmginfo:GetDamageType() == DMG_BLAST))) and ent.KnockImmunity and CurTime() >= ent.KnockImmunity then
if ent.Incapped == true then return end
ent:SetPos(ent:GetPos() + Vector(0,0,1))
ent:SetVelocity(Vector(0,0,150))
ent.KnockImmunity = CurTime() + 2
ent.GUReset = CurTime() + 0.75
if ent:GetActiveWeapon():IsValid() then
ent:GetActiveWeapon():SendWeaponAnim(ACT_VM_RELOAD)
end
timer.Simple(0.05,function()
if ent:Alive() then
ent:GetViewModel():SetNoDraw(true)
end
end)
ent.KnockedDown = true
ent:ConCommand("+duck")
umsg.Start("KnockedDownMS",ent)
umsg.End()
end
end
hook.Add("EntityTakeDamage","GETUPTakeDamage2",GETUPTakeDamage)